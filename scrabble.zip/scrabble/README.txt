README

Eric Johnson (edj36)
Kenta Takatsu (kt426)
Eric Zhang (ez79)
Pehuen Moure (ppm44)

Welcome to Scrabble!

(We assume you have Ocaml and OPAM installed per Fall 2016
 CS 3110 course installation guidelines.)

NOTE: The graphical user interface for the game works best
      when the terminals is in "full screen" mode. 

Installation:
 * Download .zip file of source code
 * $ cd /path/to/scrabble/folder
 * $ update opam
 * $ opam install ocaml-radixtree
 * $ opam install yojson
 * $ opam install ANSITerminal

Game-play:
 * $ cd /path/to/scrabble/folder
 * $ make clean
 * $ make play

Enjoy :)

* If "make" commands don't work, make sure you are in the 
  folder containing the "Makefile" *