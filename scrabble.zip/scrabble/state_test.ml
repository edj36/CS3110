open OUnit2

let tests = [
  "Test 1"  >:: (fun _ -> assert_equal 0  0 );
]
